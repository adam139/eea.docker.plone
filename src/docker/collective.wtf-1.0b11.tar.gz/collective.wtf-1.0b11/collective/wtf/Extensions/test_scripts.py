# External methods used in the tests

def inline_test_one(self, state_change):
    pass

def inline_test_two(self, state_change):
    pass

def script_section_test(self, state_change):
    pass
